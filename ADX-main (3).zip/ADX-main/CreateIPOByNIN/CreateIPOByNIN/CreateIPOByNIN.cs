﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADX.CRM.CreateIPOByNIN
{
    public class CreateIPOByNIN : CodeActivity
    {
        [Input("Transaction Type")]
        public InArgument<string> TransactionType { get; set; }
        [Input("IBAN")]
        public InArgument<string> IBAN { get; set; }
        [Input("DDS Reference")]
        public InArgument<string> DDS_Reference { get; set; }
        [Input("NIN")]
        [RequiredArgument]
        public InArgument<string> NIN { get; set; }

        [Output("Status Code")]
        public OutArgument<int> StatusCode{ get; set; }

        [Output("Message")]
        public OutArgument<string> Message { get; set; }
        [Output("Justification")]
        public OutArgument<string> Justification { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            var nin = NIN.Get<string>(context);
            var transactionType = TransactionType.Get<string>(context);
            var iBAN = IBAN.Get<string>(context);
            var dds_Reference = DDS_Reference.Get<string>(context);

            var fetchXmlCurrentUserCases = $@"
                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                    <entity name='contact'>
                        <attribute name='fullname'/>
                        <attribute name='contactid'/>
                        <attribute name='adx_investornumber'/>
                        <attribute name='adx_emiratesidnumber'/>
                        <attribute name='adx_gender'/>
                        <attribute name='createdon'/>
                        <attribute name='adx_passportnumber'/>
                        <order attribute='fullname' descending='false'/>
                        <filter type='and'>
                            <condition attribute='adx_investornumber' operator='eq' value='{nin}'/>
                        </filter>
                    </entity>
                </fetch>";

            var contactColl = service.RetrieveMultiple(
                new FetchExpression(
                    fetchXmlCurrentUserCases));
            if (contactColl == null || contactColl.Entities.Count == 0)
            {
                StatusCode.Set(context, 400);
                Message.Set(context, "IPO Not Created");
                Justification.Set(context, "there is no contact with " + nin + " exist");
            }
            else if (transactionType.ToUpper() != "IPO" && transactionType.ToUpper() != "BRK")
            {
                StatusCode.Set(context, 400);
                Message.Set(context, "IPO Not Created");
                Justification.Set(context, "there is no Transaction type = "+ transactionType + " exist , it's either IPO Or BRK");

            }
            else
            {
                EntityReference contact = new EntityReference(contactColl.Entities[0].LogicalName, contactColl.Entities[0].Id);
               
                var fetchXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                    <fetch>
                      <entity name=""adx_ipopaymenttransactionreference"">
                        <attribute name=""adx_contact"" />
                        <attribute name=""adx_iban"" />
                        <filter>
                          <condition attribute=""adx_contact"" operator=""eq"" value=""{contact.Id}"" />
                          <condition attribute=""adx_iban"" operator=""eq"" value=""{iBAN}"" />
                           <condition attribute=""statecode"" operator=""eq"" value=""{0}"" />

                        </filter>
                      </entity>
                    </fetch>";

                var ipoColl = service.RetrieveMultiple(
               new FetchExpression(
                   fetchXml));

                if(ipoColl != null && ipoColl.Entities.Count > 0 )
                {
                    var inactiveIPO = ipoColl.Entities[0];
                    inactiveIPO.Attributes["statecode"] = new OptionSetValue(1);
                    inactiveIPO.Attributes["statuscode"] = new OptionSetValue(2);
                    service.Update(inactiveIPO);
                    Entity ipo = new Entity("adx_ipopaymenttransactionreference");
                    ipo["adx_transactiontype"] = transactionType.ToUpper() == "IPO" ? new OptionSetValue(1) : transactionType.ToUpper() == "BRK" ? new OptionSetValue(2)
                        : null;
                    ipo["adx_iban"] = iBAN;
                    ipo["adx_ddsreference"] = dds_Reference;
                    ipo["adx_contact"] = contact;
                    ipo["adx_investornin"] = nin;
                    var ipoId = service.Create(ipo);
                    StatusCode.Set(context, 200);
                    Message.Set(context, "Old IPO Dectiviated and NEW IPO Created Sucuessfully");
                    Justification.Set(context, "old IPO found with the same contact and IBAN with id =" + inactiveIPO.Id.ToString() + " , new IPO Created with id = " + ipoId.ToString());


                }
                else
                {
                    Entity ipo = new Entity("adx_ipopaymenttransactionreference");
                    ipo["adx_transactiontype"] = transactionType.ToUpper() == "IPO" ? new OptionSetValue(1) : transactionType.ToUpper() == "BRK" ? new OptionSetValue(2)
                        : null;
                    ipo["adx_iban"] = iBAN;
                    ipo["adx_ddsreference"] = dds_Reference;
                    ipo["adx_contact"] = contact;
                    ipo["adx_investornin"] = nin;
                    var ipoId = service.Create(ipo);
                    StatusCode.Set(context, 200);
                    Message.Set(context, "New IPO Created Sucuessfully");
                    Justification.Set(context, "No Existing IPO related to the NIN contact and having the same IBAN , new IPO Created with id = " + ipoId.ToString());


                }

            }

        }
    }
}
