﻿using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Xrm.Sdk.Query;


namespace ADX.CRM.GetContactByNIN
{
    public class GetContactByNIN : CodeActivity
    {
        [Input("NIN")]
        [RequiredArgument]
        public InArgument<string> NIN { get; set; }

        [Output("Passport")]
        public OutArgument<string> Passport { get; set; }


        [Output("Gender")]
        public OutArgument<string> Gender { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            var nin = NIN.Get<string>(context);

            var fetchXmlCurrentUserCases = $@"
                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                    <entity name='contact'>
                        <attribute name='fullname'/>
                        <attribute name='contactid'/>
                        <attribute name='adx_investornumber'/>
                        <attribute name='adx_emiratesidnumber'/>
                        <attribute name='adx_gender'/>
                        <attribute name='createdon'/>
                        <attribute name='adx_passportnumber'/>
                        <order attribute='fullname' descending='false'/>
                        <filter type='and'>
                            <condition attribute='adx_investornumber' operator='eq' value='{nin}'/>
                        </filter>
                    </entity>
                </fetch>";

            var contactColl = service.RetrieveMultiple(
                new FetchExpression(
                    fetchXmlCurrentUserCases));
            tracingService.Trace("Start \t " +  contactColl.Entities.Count);
            if (contactColl == null || contactColl.Entities.Count == 0)
            {
                Gender.Set(context, "Not Found");
                Passport.Set(context, "Not Found");
            }
            else
            {
                var gender = contactColl.Entities[0].Contains("adx_gender") ?
                    contactColl.Entities[0].FormattedValues["adx_gender"].ToString() : "Null";

                var passport = contactColl.Entities[0].Contains("adx_passportnumber") ?
                    contactColl.Entities[0]["adx_passportnumber"].ToString() : "Null";

                Gender.Set(context, gender);
                Passport.Set(context, passport);

            }




        }
    }
}
